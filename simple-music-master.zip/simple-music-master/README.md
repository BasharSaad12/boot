## simple-music

👵 This was my first music bot!

## Run it yourself

1. Edit the **`config.js`** and fill out the things
2. Start your bot with `node music.js`

## Warning/Notes

The base idea of the music queue system came from [xtreameprogram](https://github.com/xtreameprogram)!

THIS CODE ABOVE IS REALLY REALLY BAD, it might have alot of errors other than it's not readable!

## Copyrights

© [**Abady**](https://github.com/Abady321x123)
