module.exports = {
    TOKEN: 'Your bot token here', 
    YT_API_KEY: 'Youtube API Key here', 
    prefix: 'prefix here',
    devs: ['your id/developers here']
}