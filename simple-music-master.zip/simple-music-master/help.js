exports.music = [
    {
     name: 'play', 
    },
    {
    name: 'skip'
    },
    {
    name: 'volume'
    },
    {
    name: 'np'   
    },
    {
    name: 'queue'   
    },
    {
    name: 'loop'   
    },
    {
    name: 'search'
    },
    {
    name: 'pause'
    },
    {
    name: 'resume'
    },
    {
    name: 'clear'
    }
]

exports.info = [
    {
    name: 'info'
    }, 
    {
    name: 'contact'
    },
    {
    name: 'invite'
    }
]